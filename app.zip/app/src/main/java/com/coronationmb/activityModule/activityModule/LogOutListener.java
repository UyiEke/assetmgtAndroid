package com.coronationmb.activityModule.activityModule;

public interface LogOutListener {
    void onSessionLogout();
}